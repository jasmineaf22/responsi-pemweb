<?php

$conn=mysqli_connect("localhost","root","","responsi-pemweb") or die("failed to connect");


?>